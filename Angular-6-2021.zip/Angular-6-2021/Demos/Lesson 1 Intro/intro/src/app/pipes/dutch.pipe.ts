import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dutch'
})
export class DutchPipe implements PipeTransform {

  transform(value: any, args?: any, arg2?:any): any 
  {
    return (args + " " + arg2 + " " + value).replace(/[,]/gi, '').replace(/[.]/gi, ',');
  }

}
