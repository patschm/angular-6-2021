import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfound',
  template: `<h1>Not Found</h1>`,
  styles: []
})
export class NotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
