import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-list></app-list>`,
  styles: []
})
export class AppComponent {
  title = 'PWA';
}
