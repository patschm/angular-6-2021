import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <!-- <app-basic></app-basic> -->
  <!-- <app-old><app-old> -->
  <app-latest></app-latest>
  `,
  styles: []
})
export class AppComponent {
  title = 'redux';
}
