import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainModule } from './main/main.module';
//import { SubModule } from './sub/sub.module';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing:true}),
  MainModule,
  //SubModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
